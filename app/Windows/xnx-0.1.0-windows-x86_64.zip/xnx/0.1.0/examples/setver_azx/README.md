# xnx-azx

Azure DevOps extension for the xnx utility.

Copyright (c) 2022, Alexander Iurovetski
All rights reserved under MIT license (see LICENSE file)
