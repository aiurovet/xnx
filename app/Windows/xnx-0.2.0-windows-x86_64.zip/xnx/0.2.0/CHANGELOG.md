## 0.2.0

- Modern installers: Linuxbrew, Homebrew, Chocolatey
- Added `Command.chmod()`
- Bugfix: restoring file permissions after expansion and unarchiving

## 0.1.0

- Initial version
